package edu.cseju.applicationtechshopju.model;

import java.util.List;

public interface ISync {
    void CaptureData(List<Product> productList);
}
